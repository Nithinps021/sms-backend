const twilio = require('twilio')('ACca1360422cf1921e8242ae08138816a0','cc93ac884dcb2f5e4edbe784e2535939')

function sendMessage (){
    return new Promise((resolve,reject)=>{
        twilio.messages.create({
            body:"hi message from nithin",
            from:"+12312992030",
            to:"+918078157978"
        })
        .then(res=>{
            resolve({
                status:200,
                messages:"message is send",
                res,
            })
        })
        .catch(error=>{
            reject ({
                status:404,
                messages:"something went wrong",
                error
            })
        })
    })
}

exports.handler = async (event) => {
   sendMessage()
   .then(res=>{
    console.log(res)
    return res
   })
   .catch(error=>{
    return error
   })
};

